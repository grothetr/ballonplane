/** Automatically generated file. DO NOT MODIFY */
package com.grothetr.androidgame.ballonplane;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}