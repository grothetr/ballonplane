package com.grothetr.androidgame.ballonplane;

import android.graphics.Typeface;

import com.grothetr.androidgame.framework.Pixmap;

public class Assets {
	public static Pixmap white;
	public static Typeface font;
	public static Pixmap ball;
}
