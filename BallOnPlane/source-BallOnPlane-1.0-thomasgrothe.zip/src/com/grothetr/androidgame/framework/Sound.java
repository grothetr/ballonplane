package com.grothetr.androidgame.framework;

public interface Sound {
    public void play(float volume);

    public void dispose();
}
